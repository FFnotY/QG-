#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "danlianbiao.h"

int main()
{
	LinkList L;                                     //声明一个指向单链表头节点的指针 
	InitList(&L);                                   //初始化这个单链表为空表 
	int a;
	do{
	printf("************************\n");
	printf("[1]初始化一个列表\n");
	printf("[2]插入新的节点\n");
	printf("[3]查询链表\n");
	printf("[4]删除链表\n");
	printf("[5]输出链表\n");
	printf("[6]退出系统"); 
	printf("************************\n");
	printf("\n");
	printf("请输入对应的数字（1~6）\n");
	int  b1;
	scanf("%d",&a);
	switch (a) {
		case (1):
			printf("想创建几个节点\n");
			scanf("%d",&b1);
			InitList(&L);
            List_Taillnsert(&L,b1); 
				break;
		case (2):
		    printf("在第几个位置之前插入节点");
		    int cha;
		    scanf("%d",&cha); 
		    printf("插入的数据是");
		    int newcha;
			scanf("%d",&newcha) ;
			ListInsert(&L, cha, newcha);
			printf("插入成功\n");
			break;
		case (3):
		    printf("你要查询第几个数据(按位查找)");
		    int shan;
			scanf("%d",&shan);
			printf("第%d个数据是%d",shan,GetElem( &L, shan));	
			break;
		case (4):
		    printf("删除第几个节点");
			int cut,e1;
			int *num=&e1;
			scanf("%d",&cut);
			Nodedelete( &L, cut);
			printf("删除的数据是%d",e1);
			break;
		case (5):
			displayLinkedList( &L);
		    break;	
		case (6):
			DestoryList(&L);
		    printf("退出成功");  				
			}
	} while(a!=6);
	
	return 0;	
}