#ifndef Int_xxx
#define INt_xxx

typedef struct DNode{
	int data;
	struct DNode *prior,*next;
}DNode,DLinkList;


bool InitDlinklist(DLinkList *L);
bool List_Taillnsert(DLinkList *L);
bool InsertNextDnode(DNode*p,DNode*s);
DNode *GetElem(DLinkList *L, int i);
bool  Nodedelete(DLinkList *L, int i);
bool  Nodedelete(DLinkList *L, int i);
void displayLinkedList(DLinkList* L);
bool DeleteNextDnode(DNode*p);
void DestoryList(DLinkList *L);

#endif