#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lianzhan.h"

int main()
{
    StackNode S;
    	int a;
	do{
	printf("************************\n");
	printf("[1]初始化一个链栈\n");
	printf("[2]入栈\n");
	printf("[3]判断链栈是否为空\n");
	printf("[4]删除链栈\n");
	printf("[5]输出链栈\n");
	printf("[6]退出系统"); 
	printf("************************\n");
	printf("\n");
	printf("请输入对应的数字（1~6）\n");
	int  b1;
    int i=1;
    int *e;
    int num;
    int b,c;
	scanf("%d",&a);
	switch (a) {
		case (1):
			InitStack(&S);
				break;
		case (2):
			while(b!=9999){
				printf("请输入第%d个节点的数据(不超过9999)",i);
                scanf("%d",&b);
				Push( &S,b);
                i++;
			}
			break;
		case (3):
		    Stackempty( &S);
			break;
		case (4):
		    printf("删除几个节点");
            scanf("%d",&num);
            for(i=1;i<=num;i++)
            {
                Pop(&S,&e);
                printf("%d\n",e);
            }
			break;
		case (5):
			StackTraverse( &S);
		    break;	
		case (6):
		    printf("退出成功"); 
            break;
        default:
            printf("操作错误");    			
			}
	} while(a!=6);
	
	return 0;

}


