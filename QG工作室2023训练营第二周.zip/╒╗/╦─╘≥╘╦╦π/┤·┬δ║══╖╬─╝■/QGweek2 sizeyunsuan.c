#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "4s.h"


LinkStack*  initstack()//创建栈
{
    LinkStack* S=(LinkStack*)malloc(sizeof(LinkStack));
    if(S!=NULL)
    {
        S->top=NULL;
        S->size=0;
    }
    return S;
}


int isempty(LinkStack* S)//判断栈为空
{
    if(S->top==NULL)
    {
        return 1;//栈为空
    }
    return 0;//栈不为空
}


StackNode* seqstack_top(LinkStack* S)//获取栈顶元素的数据节点
{
    if(S->size!=0)
    {
        return S->top;
    }
    return NULL;
}


StackNode* Pop(LinkStack* S)//弹出栈顶元素
{
    if(isempty(S)==0)
    {
        StackNode* account=S->top;
        S->top=S->top->next;
        S->size--;
        return account;
    }
    return NULL;
}


void Push(LinkStack* S,char x)//入栈
{
   StackNode* temp;
   temp=(StackNode*)malloc(sizeof(StackNode));
   temp->data=x;
   temp->next=S->top;
   S->top=temp;
   S->size++;
   return;
}


 //中缀表达式转后缀表达式
 char buffer[256]={0};
 
 void char_put(char ch)//用来将字符放入放入数组
 {
     static int index=0;
     buffer[index++]=ch;
 }
 int priority(char ch)//比较优先级
 {
     int ret=0;
     switch(ch)
     {
        case '+':
        case '-':
            ret=1;
            break;
        case '*':
        case '/':
            ret=2;
            break;
        default:
            break;
     }
     return ret;
 }


 int is_number(char ch)//是不是数字
 {
     return(ch>='0'&&ch<='9');//数字返回1，否则返回0
 }

 int is_operator(char ch)//是不是运算符
 {
     return(ch=='+'||ch=='-'||ch=='*'||ch=='/');
 }

 int is_left(char ch)//是不是左括号
 {
     return(ch=='(');
 }

 int is_right(char ch)//是不是右括号
 {
     return(ch==')');
 }

 int transform(char str[])
 {
     LinkStack* S=initstack();
     int i=0;
     while(str[i]!='\0')
    {
        //判断是不是数字
        if(is_number(str[i])==1)
        {
            if(is_number(str[i+1])==1)
            {
                char_put(str[i]);//数字直接输出
            }
            
        }
        else if(is_operator((str[i]))==1)
        {
            
            if(isempty(S)==0)
            {
                while((isempty(S)==0)&&(priority(str[i])<=(priority(seqstack_top(S)->data))))//栈不为空并且新运算符优先级不高于栈顶
                {
                    char_put(Pop(S)->data);
                    char_put(' ');
                }
            }
            Push(S,str[i]);
        }
        else if(is_left(str[i]))//左括号直接入栈
        {
            Push(S,str[i]);
        }
        else if(is_right(str[i]))//判断是不是右括号
        {
            while(is_left(seqstack_top(S)->data)!=1)//栈顶不是左括号的情况
            {
                char_put(Pop(S)->data);
                if(isempty(S)==1)//栈为空仍未找到左括号
                {
                    printf("没有匹配到左括号\n");
                    return -1;
                }
            }
            //匹配到左括号
            Pop(S);
        }
        else
        {
            printf("有不能识别的字符\n");
            return -1;
        }
        i++;
    }
    if(str[i]=='\0')//到结尾
    {
        while(isempty(S)==0)//弹出全部栈中元素
        {
            if(seqstack_top(S)->data=='(')//栈顶元素为左括号
            {
                printf("有没有匹配到的'(',缺少')'\n");
                return -1;
            }
            char_put(Pop(S)->data);
        }
    }
    else
    {
        printf("遍历没有完成！\n");
    }
    return 1;
 }
 
 
 
 //下方为计算后缀表达式需要的函数
 typedef struct node1
{
    int data;
    struct node1* next;
}StackNode1;
typedef struct seqstack1
{
    int size;
    StackNode1* top;
}LinkStack1;


LinkStack1*  initstack1()
{
    LinkStack1* S=(LinkStack1*)malloc(sizeof(LinkStack1));
    if(S!=NULL)
    {
        S->top=NULL;
        S->size=0;
    }
    return S;
}


int isempty1(LinkStack1* S)//判断栈为空
{
    if(S->top==NULL)
    {
        return 1;
    }
    return 0;
}


int seqstack_top1(LinkStack1* S)//获取栈顶元素
{
    if(S->size!=0)
    {
        return S->top->data;
    }
    return ;
}


int Pop1(LinkStack1* S)//弹出栈顶元素
{
    if(isempty1(S)==0)
    {
        int account=S->top->data;
        S->top=S->top->next;
        S->size--;
        return account;
    }
    return 99999;
}


void Push1(LinkStack1* S,int x)//入栈
{
   StackNode1* temp;
   temp=(StackNode1*)malloc(sizeof(StackNode1));
   temp->data=x;
   temp->next=S->top;
   S->top=temp;
   S->size++;
   return;
}


 int express(int left,int right,char yunsuanfu)
 {
     switch (yunsuanfu)
     {
        case '+':
            return left+right;
        case '-':
            return left-right;
        case '*':
            return left*right;
        case '/':
            if(right==0)
            {
                return 8888;
            }
            return left/right;
        default:
            break;
     }
     return -1;
 }

 
 int getsize(LinkStack1* stack)
 {
     return stack->size;
 }

 int calculate(char str[])//计算后缀表达式
 {
     LinkStack1* istack2=initstack1();
     int i=0;
     while(str[i]!='\0')
    {
        char a[6]={0};
        int index=0;
        if(is_number(str[i])==1)
        {
            while(is_number(str[i])==1)
            {
                a[index]=str[i];
                index++;
                i++;
            }
            //成功读取数字
            Push1(istack2,atoi(a));//将该整数入栈
        }
        else if(is_operator(str[i])==1)
        {
            int right=Pop1(istack2);
            int left=Pop1(istack2);
            int ret=express(left,right,str[i]);
            return 666;
            Push1(istack2,ret);
        }
        
        i++;
    }
    if(str[i]=='\0'&&getsize(istack2))
    {
        return seqstack_top1(istack2);
    }
    return 0;
 }
