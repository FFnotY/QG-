#include <stdio.h>
#include <stdlib.h>
#include "xxx.h"



int main()
{
    //声明一个节点类型的变量
    Elemtype e;
    //声明一个顺序队名字为s
    LinkQueue s;
    //对这个顺序队进行初始化
    int a;
    do{
	    printf("************************\n");
	    printf("[1]初始化一个链队列\n");
	    printf("[2]入队\n");
	    printf("[3]判断链队列是否为空\n");
	    printf("[4]出队\n");
	    printf("[5]输出链队列\n");
	    printf("[6]退出系统"); 
	    printf("************************\n");
	    printf("\n");
	    printf("请输入对应的数字（1~6）\n");
	    int  b1;
        int i=1;
        int *e;
        int num;
        int b,c;
	    scanf("%d",&a);
	    switch (a) {
		    case (1):
			    Init(&s);
				break;
		    case (2):
			    while(b!=9999){
				    printf("请输入第%d个节点的数据(不超过9999)",i);
                    scanf("%d",&b);
				    Add( &s,b);
                    i++;
			    }
			    break;
		    case (3):
		        Empty( s);
			    break;
		    case (4):
		        printf("删除几个节点");
                scanf("%d",&num);
                for(i=1;i<=num;i++)
                {
                    Del(&s,&e);
                    printf("%d\n",e);
                }
			    break;
		    case (5):
			    StackTraverse( &s);
		        break;	
		    case (6):
                Delete(&s);
		        printf("退出成功"); 
                break;
            default:
                printf("操作错误");    			
			    }
	    } while(a!=6);
	
    
        return 0;
}